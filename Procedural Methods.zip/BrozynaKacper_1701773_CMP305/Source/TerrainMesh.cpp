#include "TerrainMesh.h"

TerrainMesh::TerrainMesh( ID3D11Device* device, ID3D11DeviceContext* deviceContext, int lresolution ) :
	PlaneMesh( device, deviceContext, lresolution ) 
{
	Resize( resolution );
	Regenerate(device, deviceContext);
	perlin = new Perlin;
}

//Cleanup the heightMap
TerrainMesh::~TerrainMesh() {
	delete[] heightMap;
	heightMap = 0;
}


//Fill an array of floats that represent the height values at each grid point.
//Here we are producing a Sine wave along the X-axis
void TerrainMesh::BuildHeightMap() {
	float height = 0.0f;

	//Scale everything so that the look is consistent across terrain resolutions
	const float scale =  terrainSize / (float)resolution;

	//setting out a flat plane
	for( int j = 0; j < ( resolution ); j++ ) {
		for( int i = 0; i < ( resolution ); i++ ) {
			heightMap[( j * resolution ) + i] = 0;
		}
	}	
}

//resizes the plane to the desired resolution
void TerrainMesh::Resize( int newResolution ) {
	resolution = newResolution;
	heightMap = new float[resolution * resolution];
	if( vertexBuffer != NULL ) {
		vertexBuffer->Release();
	}
	vertexBuffer = NULL;
}

//faulting option for terrain 
void TerrainMesh::Faulting(ID3D11Device* device, ID3D11DeviceContext* deviceContext)
{
	//initialising variables
	smoothMap = heightMap;

	XMFLOAT3 faultVector;
	XMFLOAT3 crossProduct;
	XMFLOAT3 targetVector;

	int	randomX = rand() % resolution;
	int	randomY = rand() % resolution;
	int	randomX2 = rand() % resolution;
	int	randomY2 = rand() % resolution;

	//calculating the fault line vector
	faultVector.x = randomX2 - randomX;
	faultVector.y = randomY2 - randomY;
	faultVector.z = heightMap[(randomY2 * resolution) + randomX2] - heightMap[(randomY * resolution) + randomX];

	//loops all mesh positions 
	for (int j = 0; j < (resolution); j++) {
		for (int i = 0; i < (resolution); i++) {

			//calculates cross product using the fault line vector and the target vector
			targetVector.x = randomX - i;
			targetVector.y = randomY - j;
			targetVector.z = heightMap[(randomY * resolution) + randomX] - heightMap[(j * resolution) + i];

			crossProduct.x = faultVector.y * targetVector.z - faultVector.z * targetVector.y;
			crossProduct.y = faultVector.z * targetVector.x - faultVector.x * targetVector.z;
			crossProduct.z = faultVector.x * targetVector.y - faultVector.y * targetVector.x;

			//moves the point up or down depending on the magnitude
			if (crossProduct.z > 0)
			{
				smoothMap[(j * resolution) + i] += 1;
			}
			else
			{
				smoothMap[(j * resolution) + i] += -1;
			}
		}
	}

	//update the current height map
	heightMap = smoothMap;
	smoothdone = true;
	Regenerate(device, deviceContext);
}



void TerrainMesh::Smooth(ID3D11Device* device, ID3D11DeviceContext* deviceContext)
{
	//sets variables
	smoothMap = heightMap;
	avg = 0;

	//loops through all the mesh positions
	for (int j = 0; j < (resolution); j++)
	{
		for (int i = 0; i < (resolution); i++)
		{
			// loops through a 3x3 box with the middle point being the current position of the mesh 
			for (int k = -1; k < 2; k++)
			{
				for (int l = -1; l < 2; l++)
				{
					//gets the average of all the points inside the 3x3 box that are inside the height map
					if (((j + k) * resolution + (i + l)) > 0 && ((j + k) * resolution) + (i + l) < resolution*resolution) 
					{
						avg += heightMap[(((j + k) * resolution)) + (i + l)];
						divide++;
					}
				}
			}

			//sets the smoothed position of the average heights to the current point of the mesh
			avg = avg / divide;
			smoothMap[(j * resolution) + i] = avg;
			
			//resetting values
			avg = 0;
			divide = 0;
		}
	}

	//update the current height map
	smoothdone = true;
	heightMap = smoothMap;
	Regenerate(device, deviceContext);
}

void TerrainMesh::PerlinNoise(ID3D11Device* device, ID3D11DeviceContext* deviceContext, float Amplitude, float Frequency)
{
	//randomises the seeding the 
	perlin->RandomisePermutations(true);

	//initialise variables
	float m_Amplitude = 25.0f;
	float m_Frequency = 35.0f;
	float offset = rand() % 10000;
	offset /= 33.3f;
	float ampVar;
	float freqVar;
	float height;

	//loops for all the points in the mesh
	for (int j = 0; j < (resolution); j++) 
	{
		for (int i = 0; i < (resolution); i++) 
	
		{
			//resetting variables
			ampVar = Amplitude;
			freqVar= Frequency;
			height = 0;

			//adds to the current height each iteration with increased amplitude and decreased frequency
			for (int iterations = 0; iterations < 5; iterations++);
			{
				height += (0.5f - perlin->noise(offset + ((float)i) * freqVar, 0.0f, offset + ((float)j) * freqVar)) * ampVar;
				freqVar *= 2.0f;
				ampVar *= 0.5;
			}

			//adds the extra height to the current height of the point in the height map
			heightMap[(j * resolution) + i] += height;
		}
	}
		
	//update the height map
	smoothdone = true;
	Regenerate(device, deviceContext);
}


// Set up the heightmap and create or update the appropriate buffers
void TerrainMesh::Regenerate( ID3D11Device * device, ID3D11DeviceContext * deviceContext ) {

	bool quilt = false;
	VertexType* vertices;
	unsigned long* indices;
	int index, i, j;
	float positionX, height, positionZ, u, v, increment;
	D3D11_BUFFER_DESC vertexBufferDesc, indexBufferDesc;
	D3D11_SUBRESOURCE_DATA vertexData, indexData;
	
	//updates the current height map 
	if (smoothdone)
	{
		smoothdone = false;
	}

	//completely rebuilds another height map
	else
	{
		BuildHeightMap();
	}

	// Calculate the number of vertices in the terrain mesh.
	// We share vertices in this mesh, so the vertex count is simply the terrain 'resolution'
	// and the index count is the number of resulting triangles * 3 OR the number of quads * 6
	vertexCount = resolution * resolution;

	indexCount = ( ( resolution - 1 ) * ( resolution - 1 ) ) * 6;
	vertices = new VertexType[vertexCount];
	indices = new unsigned long[indexCount];

	index = 0;

	// UV coords.
	u = 0;
	v = 0;
	increment = m_UVscale / resolution;

	//Scale everything so that the look is consistent across terrain resolutions
	const float scale = terrainSize / (float)resolution;

	//Set up vertices
	for( j = 0; j < ( resolution ); j++ ) {
		for( i = 0; i < ( resolution ); i++ ) {
			positionX = (float)i * scale;
			positionZ = (float)( j ) * scale;

			height = heightMap[index];
			vertices[index].position = XMFLOAT3( positionX, height, positionZ );
			vertices[index].texture = XMFLOAT2( u, v );

			u += increment;
			index++;
		}
		u = 0;
		v += increment;
	}

	//Set up index list
	index = 0;
	for( j = 0; j < ( resolution - 1 ); j++ ) {
		for( i = 0; i < ( resolution - 1 ); i++ ) {
			if (quilt == false)
			{
				//Build index array
				indices[index] = (j * resolution) + i;
				indices[index + 1] = ((j + 1) * resolution) + (i + 1);
				indices[index + 2] = ((j + 1) * resolution) + i;

				indices[index + 3] = (j * resolution) + i;
				indices[index + 4] = (j * resolution) + (i + 1);
				indices[index + 5] = ((j + 1) * resolution) + (i + 1);
				index += 6;
				quilt = true;
			}
			else
			{
				//Build index array
				indices[index] = (j * resolution) + i;
				indices[index + 1] = (j * resolution) + (i + 1);
				indices[index + 2] = ((j + 1) * resolution) + i;

				indices[index + 3] = (j * resolution) + (i + 1);
				indices[index + 4] = ((j + 1) * resolution) + (i + 1);
				indices[index + 5] = ((j + 1) * resolution) + i;
				index += 6;
				quilt = false;
			}


		}
	}

	//Set up normals
	for( j = 0; j < ( resolution - 1 ); j++ ) {
		for( i = 0; i < ( resolution - 1 ); i++ ) {
			//Calculate the plane normals
			XMFLOAT3 a, b, c;	//Three corner vertices
			a = vertices[j * resolution + i].position;
			b = vertices[j * resolution + i + 1].position;
			c = vertices[( j + 1 ) * resolution + i].position;

			//Two edges
			XMFLOAT3 ab( c.x - a.x, c.y - a.y, c.z - a.z );
			XMFLOAT3 ac( b.x - a.x, b.y - a.y, b.z - a.z );
			
			//Calculate the cross product
			XMFLOAT3 cross;
			cross.x = ab.y * ac.z - ab.z * ac.y;
			cross.y = ab.z * ac.x - ab.x * ac.z;
			cross.z = ab.x * ac.y - ab.y * ac.x;
			float mag = ( cross.x * cross.x ) + ( cross.y * cross.y ) + ( cross.z * cross.z );
			mag = sqrtf( mag );
			cross.x/= mag;
			cross.y /= mag;
			cross.z /= mag;
			vertices[j * resolution + i].normal = cross;
		}
	}

	//Smooth the normals by averaging the normals from the surrounding planes
	XMFLOAT3 smoothedNormal( 0, 1, 0 );
	for( j = 0; j < resolution; j++ ) {
		for( i = 0; i < resolution; i++ ) {
			smoothedNormal.x = 0;
			smoothedNormal.y = 0;
			smoothedNormal.z = 0;
			float count = 0;
			//Left planes
			if( ( i - 1 ) >= 0 ) {
				//Top planes
				if( ( j ) < ( resolution - 1 ) ) {
					smoothedNormal.x += vertices[j * resolution + ( i - 1 )].normal.x;
					smoothedNormal.y += vertices[j * resolution + ( i - 1 )].normal.y;
					smoothedNormal.z += vertices[j * resolution + ( i - 1 )].normal.z;
					count++;
				}
				//Bottom planes
				if( ( j - 1 ) >= 0 ) {
					smoothedNormal.x += vertices[( j - 1 ) * resolution + ( i - 1 )].normal.x;
					smoothedNormal.y += vertices[( j - 1 ) * resolution + ( i - 1 )].normal.y;
					smoothedNormal.z += vertices[( j - 1 ) * resolution + ( i - 1 )].normal.z;
					count++;
				}
			}
			//right planes
			if( ( i ) <( resolution - 1 ) ) {

				//Top planes
				if( ( j ) < ( resolution - 1 ) ) {
					smoothedNormal.x += vertices[j * resolution + i].normal.x;
					smoothedNormal.y += vertices[j * resolution + i].normal.y;
					smoothedNormal.z += vertices[j * resolution + i].normal.z;
					count++;
				}
				//Bottom planes
				if( ( j - 1 ) >= 0 ) {
					smoothedNormal.x += vertices[( j - 1 ) * resolution + i].normal.x;
					smoothedNormal.y += vertices[( j - 1 ) * resolution + i].normal.y;
					smoothedNormal.z += vertices[( j - 1 ) * resolution + i].normal.z;
					count++;
				}
			}
			smoothedNormal.x /= count;
			smoothedNormal.y /= count;
			smoothedNormal.z /= count;

			float mag = sqrt( ( smoothedNormal.x * smoothedNormal.x ) + ( smoothedNormal.y * smoothedNormal.y ) + ( smoothedNormal.z * smoothedNormal.z ) );
			smoothedNormal.x /= mag;
			smoothedNormal.y /= mag;
			smoothedNormal.z /= mag;

			vertices[j * resolution + i].normal = smoothedNormal;
		}
	}
	//If we've not yet created our dyanmic Vertex and Index buffers, do that now
	if( vertexBuffer == NULL ) {
		CreateBuffers( device, vertices, indices );
	}
	else {
		//If we've already made our buffers, update the information
		D3D11_MAPPED_SUBRESOURCE mappedResource;
		ZeroMemory( &mappedResource, sizeof( D3D11_MAPPED_SUBRESOURCE ) );

		//  Disable GPU access to the vertex buffer data.
		deviceContext->Map( vertexBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource );
		//  Update the vertex buffer here.
		memcpy( mappedResource.pData, vertices, sizeof( VertexType ) * vertexCount );
		//  Reenable GPU access to the vertex buffer data.
		deviceContext->Unmap( vertexBuffer, 0 );
	}

	// Release the arrays now that the buffers have been created and loaded.
	delete[] vertices;
	vertices = 0;
	delete[] indices;
	indices = 0;
}

//Create the vertex and index buffers that will be passed along to the graphics card for rendering
//For CMP305, you don't need to worry so much about how or why yet, but notice the Vertex buffer is DYNAMIC here as we are changing the values often
void TerrainMesh::CreateBuffers( ID3D11Device* device, VertexType* vertices, unsigned long* indices ) {

	D3D11_BUFFER_DESC vertexBufferDesc, indexBufferDesc;
	D3D11_SUBRESOURCE_DATA vertexData, indexData;

	// Set up the description of the dyanmic vertex buffer.
	vertexBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
	vertexBufferDesc.ByteWidth = sizeof( VertexType ) * vertexCount;
	vertexBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
	vertexBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
	vertexBufferDesc.MiscFlags = 0;
	vertexBufferDesc.StructureByteStride = 0;
	// Give the subresource structure a pointer to the vertex data.
	vertexData.pSysMem = vertices;
	vertexData.SysMemPitch = 0;
	vertexData.SysMemSlicePitch = 0;
	// Now create the vertex buffer.
	device->CreateBuffer( &vertexBufferDesc, &vertexData, &vertexBuffer );

	// Set up the description of the static index buffer.
	indexBufferDesc.Usage = D3D11_USAGE_DEFAULT;
	indexBufferDesc.ByteWidth = sizeof( unsigned long ) * indexCount;
	indexBufferDesc.BindFlags = D3D11_BIND_INDEX_BUFFER;
	indexBufferDesc.CPUAccessFlags = 0;
	indexBufferDesc.MiscFlags = 0;
	indexBufferDesc.StructureByteStride = 0;
	// Give the subresource structure a pointer to the index data.
	indexData.pSysMem = indices;
	indexData.SysMemPitch = 0;
	indexData.SysMemSlicePitch = 0;

	// Create the index buffer.
	device->CreateBuffer( &indexBufferDesc, &indexData, &indexBuffer );
}