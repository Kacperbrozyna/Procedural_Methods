// Application.h
#ifndef _APP1_H
#define _APP1_H

// Includes
#include "DXF.h"	// include dxframework
#include "LightShader.h"
#include "TerrainMesh.h"
#include "ManipulationShader.h"


class App1 : public BaseApplication
{
public:
	App1();
	~App1();
	void init(HINSTANCE hinstance, HWND hwnd, int screenWidth, int screenHeight, Input* in, bool VSYNC, bool FULL_SCREEN);

	bool frame();

protected:
	bool render();
	void gui();

private:
	//initialising variables
	LightShader* shader;
	ManipulationShader* waveShader;
	TerrainMesh* m_Terrain;
	TerrainMesh* m_Sea;
	float totalTime;
	Light* light;
	float steepness[3];
	float wavelength[3];
	XMFLOAT4 wave[3];

	//setting variables
	int terrainResolution = 128;
	float oceanPos = 0;
	float snowPos = 10;
	float rockPos = 15;
	float Amplitude = 25;
	float Frequency = 35;
	bool rockLock = true;

};

#endif